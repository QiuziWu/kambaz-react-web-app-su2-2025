export default function Lab3() {
    return (
        <div>
            <h3>Lab 3</h3>
            <p>Let's learn about JavaScript</p>
        </div>
    )
}