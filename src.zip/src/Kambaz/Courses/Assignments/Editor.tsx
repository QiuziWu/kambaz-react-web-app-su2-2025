import { Form, Button, Row, Col, Container } from "react-bootstrap";

export default function AssignmentEditor() {
    return (
        <div id="wd-assignments-editor">
            <Form>
                <Form.Group className="mb-3" controlId="wd-name">
                    <Form.Label className="mb-2">Assignment Name</Form.Label>
                    <Form.Control value="A1 - ENV + HTM" />
                </Form.Group>

                <Form.Group className="mb-3" controlId="wd-description">
                    <Form.Control as="textarea" rows={8} cols={50}>
                        The assignment is available online Submit a
                        link to the landing page of your Web
                        application running on Netlify. The landing
                        page should include the following: Your full
                        name and section Links to each of the lab
                        assignments Link to the Kanbas application
                        Links to all relevant source code repositories
                        The Kanbas application should include a link
                        to navigate back to the landing page.
                    </Form.Control>
                </Form.Group>
                <br /><br />
                <Form.Group className="mb-3" controlId="wd-points">
                    <Form.Label>Points</Form.Label>
                    <Form.Control type="number" value={100} />
                </Form.Group>

                <Container>
                    <Row className="mb-2">
                        <Col className="text-end" xs={3}>Points</Col>
                        <Col>
                            <Form.Control id="wd-points" value={100} />
                        </Col>
                    </Row>

                    <Row className="mb-2">
                        <Col className="text-end" xs={3}>Assignment Group</Col>
                        <Col>
                            <Form.Select id="wd-assignment-group">
                                <option value="ASSIGNMENTS">ASSIGNMENTS</option>
                            </Form.Select>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col className="text-end" xs={3}>Display Grade As</Col>
                        <Col>
                            <Form.Select id="wd-grade-display">
                                <option value="PERCENT">Percentage</option>
                            </Form.Select>
                        </Col>
                    </Row>

                    <Row className="mb-2">
                        <Col className="text-end" xs={3}>Submission Type</Col>
                        <Col>
                            <div className="border border-gray rounded-2 p-3">
                                <Form.Select id="wd-submission-type" className="mb-2">
                                    <option value="ONLINE">Online</option>
                                </Form.Select>
                                <Form.Label className="ms-2 mb-2"><b>Online Entry Options</b></Form.Label>
                                <Form.Check className="ms-2 mb-2" type="checkbox" name="wd-online-entry-checkbox" id="wd-online-entry" label="Text Entry" />
                                <Form.Check className="ms-2 mb-2" type="checkbox" name="wd-online-entry-checkbox" id="wd-online-entry" label="Website URL" />
                                <Form.Check className="ms-2 mb-2" type="checkbox" name="wd-online-entry-checkbox" id="wd-online-entry" label="Media Recordings" />
                                <Form.Check className="ms-2 mb-2" type="checkbox" name="wd-online-entry-checkbox" id="wd-online-entry" label="Student Annotation" />
                                <Form.Check className="ms-2 mb-2" type="checkbox" name="wd-online-entry-checkbox" id="wd-online-entry" label="File Uploads" />
                            </div>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col className="text-end" xs={3}>Assign</Col>
                        <Col>
                            <div className="border border-grey rounded-2 p-3">
                                <Form.Group className="mb-4">
                                    <Form.Label className="mb-2">Assign to</Form.Label>
                                    <Form.Select id="wd-assign-to">
                                        <option value="EVERY">Everyone</option>
                                    </Form.Select>
                                </Form.Group>
                                <Form.Group className="mb-4">
                                    <Form.Label className="mb-2"><b>Due</b></Form.Label>
                                    <Form.Control type="date" id="wd-assignment-due" defaultValue="2025-05-20" />
                                </Form.Group>
                                <Form.Group>
                                    <Row>
                                        <col>
                                            <Form.Label className="mb-2"> Available from</Form.Label>
                                            <Form.Control type="date" id="wd-assignment-due" defaultValue="2024-05-06" />
                                        </col>
                                        <col>
                                            <Form.Label className="mb-2"> Until </Form.Label>
                                            <Form.Control type="date" id="wd-assignment-due" defaultValue="2024-05-20" />
                                        </col>
                                    </Row>
                                </Form.Group>
                            </div>
                        </Col>
                    </Row>
                </Container>

                <hr />
                <div className="d-flex justify-content-end">
                    <Button variant="secondary" className="me-2">Cancel</Button>
                    <Button variant="danger">Save</Button>
                </div>
            </Form>
        </div>
    );
}